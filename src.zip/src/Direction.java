/**
 * Created by austinzhang on 4/18/17.
 */
public enum Direction {
    LEFT, RIGHT, UP, DOWN
}
