import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 * Created by austinzhang on 4/19/17.
 */
public class PlayerInputHandler extends Thread {
    private Socket socket;
    private GridDisplay display;
    private String serializedGrid;

    public PlayerInputHandler(Socket socket, GridDisplay display) {
        this.socket = socket;
        this.display = display;
    }

    @Override
    public void run() {
        while (!socket.isClosed()) {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String message = in.readLine();
                if (message.contains("wins")) {
                    display.showMessageDialog(message + ". Exit Quickly Before The Game Starts!");
                }
                else {
                    serializedGrid = message;  //wait for message from server
                }
            } catch (IOException exception) {
                exception.printStackTrace();
            }
        }
    }

    public String getSerializedGrid() {
        return serializedGrid;
    }
}
